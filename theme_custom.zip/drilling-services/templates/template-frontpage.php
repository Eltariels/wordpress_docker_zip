<?php 
/**
Template Name: Frontpage
*/

get_header();

get_template_part('template-parts/sections/section','slider');
get_template_part('template-parts/sections/section','service');
get_template_part('template-parts/sections/section','blog');

get_footer(); ?>