<?php if ( ! is_active_sidebar( 'drilling-services-sidebar-primary' ) ) {	return; } ?>
<div class="col-lg-4">
	<div class="sidebar">
		<?php dynamic_sidebar('drilling-services-sidebar-primary'); ?>
	</div>
</div>